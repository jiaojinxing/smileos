#include "upscreen.h"

#define UP_VIDEO_MODE_TEXT		1
#define UP_VIDEO_MODE_GRAPH		2

#define _REG16 *(volatile u16 *)
#define _REG32 *(volatile u32 *)

#define REG_BGSCREEN(screen) (0x04000000 + (screen * 0x1000))

#define PA_BGXX(screen, bg) _REG32(0x4000008 + (0x1000 * screen) + (bg << 4))
#define PA_BGXY(screen, bg) _REG32(0x400000C + (0x1000 * screen) + (bg << 4))
#define PA_BGXPA(screen, bg) _REG16(0x4000000 + (0x1000 * screen) + (bg << 4))
#define PA_BGXPB(screen, bg) _REG16(0x4000002 + (0x1000 * screen) + (bg << 4))
#define PA_BGXPC(screen, bg) _REG16(0x4000004 + (0x1000 * screen) + (bg << 4))
#define PA_BGXPD(screen, bg) _REG16(0x4000006 + (0x1000 * screen) + (bg << 4))
#define REG_BGCNT(screen, bg_number) (0x4000008 + (screen * 0x1000) + (bg_number << 1))

void CUpScreen::PA_Default16bitInit(u8 screen, u8 bg_priority)
{
	PA_BGXPA(screen, 3) = 1 << 8;
	PA_BGXPB(screen, 3) = 0;
	PA_BGXPC(screen, 3) = 0;
	PA_BGXPD(screen, 3) = 1 << 8;
	PA_BGXX(screen, 3) = 0;
	PA_BGXY(screen, 3) = 0;	

	_REG16(REG_BGSCREEN(screen)) &= ~7;
	_REG16(REG_BGSCREEN(screen)) |= (0x100 << (3)) | MODE_3_2D;

	_REG16(REG_BGCNT(screen, 3)) = bg_priority | BG_BMP16_256x256 | BG_BMP_BASE(2);
}

CUpScreen::CUpScreen()
{
    this->InitBasic();
}
CUpScreen::~CUpScreen()
{
    this->Destroy();
}
int CUpScreen::InitBasic()
{
    return OK;
}
int CUpScreen::Init()
{
    this->InitBasic();
    //add your code
    return OK;
}
int CUpScreen::Destroy()
{
    //add your code
    this->InitBasic();
    return OK;
}
int CUpScreen::Print()
{
    return TRUE;
}

int CUpScreen::SetGraphMode_16bit()
{
	CUpScreen::PA_Default16bitInit(1,3);
	return OK;
}

u16 * CUpScreen::GetFVram_16bit()
{
	return (u16*)BG_BMP_RAM_SUB(2);
}

int CUpScreen::ClearConsole()
{
	int i;

	for(i = 0; i < 30; i++)
		LOG("\n");

	return OK;
}

int CUpScreen::ClearScreen_16bit(u16 color)
{
	int i;

	u16 *p = CUpScreen::GetFVram_16bit();
	
	for(i=0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++)
	{
		p[i] = color;
	}

	return OK;
}

int CUpScreen::SetGraphMode_8bit()
{
  
 	SUB_BG3_CR = BG_BMP8_256x256;
    SUB_BG3_XDX = 1 << 8;
    SUB_BG3_XDY = 0;
    SUB_BG3_YDX = 0;
    SUB_BG3_YDY = 1 << 8;

	return OK;
}
