#include "gui_time.h"

#define REG_BASE            0x04000000
#define REG_END             (REG_BASE +  0x300)
#define REG_TM0CNT          (REG_BASE + 0x100)
#define REG_TM0CNT_L        (REG_BASE + 0x100)
#define REG_TM0CNT_H        (REG_BASE + 0x102)
#define REG_TM1CNT          (REG_BASE + 0x104)
#define REG_TM1CNT_L        (REG_BASE + 0x104)
#define REG_TM1CNT_H        (REG_BASE + 0x106)
#define REG_TM2CNT          (REG_BASE + 0x108)
#define REG_TM2CNT_L        (REG_BASE + 0x108)
#define REG_TM2CNT_H        (REG_BASE + 0x10a)
#define REG_TM3CNT          (REG_BASE + 0x10c)
#define REG_TM3CNT_L        (REG_BASE + 0x10c)
#define REG_TM3CNT_H        (REG_BASE + 0x10e)

u16 * timer_counter;
u16 * timer_attr;
static int sys_time = 0;

int set_current_timer(int cur)
{
	if(cur==0)
	{
		timer_counter = (u16*)REG_TM0CNT_L;
		timer_attr = (u16 *)REG_TM0CNT_H;
	}
	else if(cur==1)
	{
		timer_counter = (u16*)REG_TM1CNT_L;
		timer_attr = (u16 *)REG_TM1CNT_H;	
	}
	else if(cur==2)
	{
		timer_counter = (u16*)REG_TM2CNT_L;
		timer_attr = (u16 *)REG_TM2CNT_H;
	}
	else if(cur==3)
	{
		timer_counter = (u16*)REG_TM3CNT_L;
		timer_attr = (u16 *)REG_TM3CNT_H;
	}
	return OK;
}

int start_timer()
{
	(*timer_attr)&=0xFFFB;
	//1024��CPU���ڼ���������1
	(*timer_attr)|=0x0003;
	//��7λ����timer�Ŀ���
	(*timer_attr)|=0x0080;

	*timer_counter = 0xFFE0;
	
	return OK;
}

int stop_timer()
{
	//��7λ����timer�Ŀ���
	(*timer_attr)&=0xFF7F;
	return OK;
}

u16 get_timer_count()
{
	return *timer_counter;
}

void set_timer_count(u16 tc)
{
	*timer_counter = tc;
}

int timer_int_enable()
{
	//����λ�����ж�ʹ�ܵĿ���
	(*timer_attr)|=0x0040;
	return OK;
}

int timer_int_disable()
{
	//����λ�����ж�ʹ�ܵĿ���
	(*timer_attr)&=0xFFBF;
	return OK;
}

void timer_int3_handler()
{
	sys_time++;
	*timer_counter = 0xFFE0;
}

void install_timer3_int_handler(void)
{
	irqSet(IRQ_TIMER3,timer_int3_handler);
}

int get_sys_time()
{
	return sys_time;
}

int sleep(int mSecond)
{
	int i,t = 0;
	for(i = 0; i < mSecond*10000; i++)
	{
		t += i;
	}

	return t;
}