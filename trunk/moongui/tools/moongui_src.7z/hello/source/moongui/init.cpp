#include "init.h"
#include "upscreen.h"

int init_all()
{
	irqInit();
	irqSet(IRQ_VBLANK, 0);

	fatInitDefault();
	GAL_InitGraph();
	
	CRect::InitRectPool();
	afx.Init();
	
	set_current_timer(3);
	timer_int_enable();
	install_timer3_int_handler();
	start_timer();

	SetStockImgBuf(afx.mem_img->p);

	fill_rect(0,0,256,192,RGB(31,31,31));
	
	afx.wndmgr->AddWindow(CDesktop::CreateDesktop());
	
	afx.mouse->SetPos(100,100);
	afx.mouse->SetPos(100,100);
	afx.mouse->Show();
	
	return OK;
}
