#ifndef __INIT_H
#define __INIT_H
	
#include "moongui.h"

int init_all();

#endif
