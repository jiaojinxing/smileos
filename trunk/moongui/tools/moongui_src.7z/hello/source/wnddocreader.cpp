#include "wnddocreader.h"
#include "upscreen.h"
#include "wndfilemgr.h"

#define UP_SCREEN_WIDTH		256
#define UP_SCREEN_HEIGHT	192
#define MAP_RECT_WIDTH		150

CWndDocReader::CWndDocReader()
{
    this->InitBasic();
}
CWndDocReader::~CWndDocReader()
{
    this->Destroy();
}
int CWndDocReader::InitBasic()
{
    CWindow::InitBasic();
	
	this->in_loop = 0;
	this->is_moving = 0;
	this->mem_pages = NULL;
	this->mem_dot_file = NULL;
	this->index_file = NULL;
	this->vram = NULL;
	this->file = NULL;
	this->dot_img_height = 0;
	this->dot_img_width = 0;
	this->dot_img_offx = 0;
	this->dot_img_offy = 0;
	this->drag_mode = 0;
	this->drag_offx = 0;
	this->drag_offy = 0;
	this->win_id_filemgr = 0;
	this->cur_page = 0;
	this->ins_line_pos = 0;

    return OK;
}
int CWndDocReader::Init()
{
    this->InitBasic();
    CWindow::Init();

    CUpScreen::SetGraphMode_16bit();
	this->vram = CUpScreen::GetFVram_16bit();
	NEW(this->mem_pages,CMem);
	this->mem_pages->Malloc(100);

    return OK;
}
int CWndDocReader::Destroy()
{
	CUpScreen::ClearScreen_16bit(COLOR_BLACK);
	DEL(this->mem_pages);
	this->CloseFile();

    CWindow::Destroy();
    this->InitBasic();
    return OK;
}
int CWndDocReader::OnCreate(int wparam, int lparam)
{
	NEW(this->btn_up,CButton);
	this->btn_up->Init();
	this->btn_up->SetText("��һҳ");
	this->btn_up->SetRect(175,50,56,21);
	
	NEW(this->btn_down,CButton);
	this->btn_down->Init();
	this->btn_down->SetText("��һҳ");
	this->btn_down->SetRect(175,75,56,21);
	
	NEW(this->leb_page,CLineEditor);
	this->leb_page->Init();
	this->leb_page->SetRect(170,105,36,16);
	this->leb_page->SetStyle(WS_BORDER);
	this->leb_page->SetText("1");
	
	NEW(this->btn_go,CButton);
	this->btn_go->Init();
	this->btn_go->SetText("��ת");
	this->btn_go->SetRect(210,105,31,16);
	
	NEW(this->btn_open,CButton);
	this->btn_open->Init();
	this->btn_open->SetText("��");
	this->btn_open->SetRect(175,25,56,21);
	
	NEW(this->st_1,CStatic);
	this->st_1->Init();
	this->st_1->SetText("0/0");
	this->st_1->SetRect(175,130,56,21);
	this->st_1->SetStyle(SS_LEFT);
	
	this->AddControl(this->btn_up);
	this->AddControl(this->btn_down);
	this->AddControl(this->leb_page);
	this->AddControl(this->btn_go);
	this->AddControl(this->btn_open);
	this->AddControl(this->st_1);
	
    return OK;
}
int CWndDocReader::OnCommand(int wparam, int lparam)
{
	if(lparam == this->btn_open->id)
	{
		if( ! afx.wndmgr->IsWindow(this->win_id_filemgr))
		{
			this->win_id_filemgr = CWndFileMgr::Create(this->id,"/","��");
		}
	}

	if(lparam == this->btn_down->id)
	{
		this->GotoPage(this->cur_page + 1);
	}

	if(lparam == this->btn_up->id)
	{
		this->GotoPage(this->cur_page - 1);
	}
	if(lparam == this->btn_go->id)
	{
		CMem mem;

		LOCAL_MEM(mem);
		this->leb_page->GetText(&mem);

		this->GotoPage(atoi(mem.p) - 1);
	}
	
    return OK;
}
int CWndDocReader::OnLButtonDown(int wparam, int lparam)
{
	CRect rc;
	int x,y;

	if(!this->IsDocOpened())
		return ERROR;
	
	if(this->drag_mode )
		return ERROR;
	
	afx.wndmgr->SetCaptureByIndex(afx.wndmgr->IdToIndex(this->id));
	
	x = LOWORD(lparam);
	y = HIWORD(lparam);
	
	this->GetDragRect(&rc);
	if(rc.PtInRect(x,y))
	{
		this->drag_mode = 1;
		this->drag_offx = x - rc.left;
		this->drag_offy = y - rc.top;
	}
	
    return OK;
}
int CWndDocReader::OnLButtonUp(int wparam, int lparam)
{
	this->drag_mode = 0;
	afx.wndmgr->ReleaseCaptureByIndex(afx.wndmgr->IdToIndex(this->id));
    return OK;
}
int CWndDocReader::OnMouseMove(int wparam, int lparam)
{
	if(!this->IsDocOpened())
		return ERROR;

	if(this->drag_mode == 0)
		return ERROR;
	
	int x,y,dot_x,dot_y;
	CRect rc;
	
	x = (short)LOWORD(lparam);
	y = (short)HIWORD(lparam);
	
	this->GetMapRect(&rc);
	
	x -= rc.left;
	y -= rc.top;
	
	x -= this->drag_offx;
	y -= this->drag_offy;

	dot_x = x * this->dot_img_width / rc.GetWidth();
	dot_y = y * this->dot_img_height / rc.GetHeight();
	
	this->MoveTo(dot_x,dot_y);

    return OK;
}
int CWndDocReader::OnKeyUp(int wparam, int lparam)
{
	this->is_moving = 0;
	return OK;
}

int CWndDocReader::OnKeyDown(int wparam, int lparam)
{
	if(!this->IsDocOpened())
		return ERROR;

	if(this->in_loop)
		return ERROR;
	
	if(lparam == KEY_L)
	{
		if(this->dot_img_offx > this->ins_line_pos)
			this->MoveTo(this->ins_line_pos,this->dot_img_offy);
		else
			this->MoveTo(0,this->dot_img_offy);
		return OK;
	}

	if(lparam == KEY_R)
	{
		if(this->dot_img_offx  < this->ins_line_pos - UP_SCREEN_WIDTH)
			this->MoveTo( this->ins_line_pos - UP_SCREEN_WIDTH,this->dot_img_offy);
		else
			this->MoveTo(this->dot_img_width,this->dot_img_offy);
		return OK;
	}

	if(lparam == KEY_SELECT)
	{
		//this->GotoPage(this->cur_page - 1);
		this->SetInsLinePos(this->dot_img_offx);
		return OK;
	}

	if(lparam == KEY_START)
	{
		this->GotoPage(this->cur_page + 1 );
		return OK;
	}
	
	if(lparam == KEY_X)
	{
		this->MoveTo(this->dot_img_offx,this->dot_img_offy - UP_SCREEN_HEIGHT);
		return OK;
	}
	if(lparam == KEY_B)
	{
		this->MoveTo(this->dot_img_offx,this->dot_img_offy + UP_SCREEN_HEIGHT);
		return OK;
	}

	if(lparam == KEY_Y)
	{
		this->MoveTo(this->dot_img_offx - UP_SCREEN_WIDTH,this->dot_img_offy);
		return OK;
	}
	if(lparam == KEY_A)
	{
		this->MoveTo(this->dot_img_offx + UP_SCREEN_WIDTH,this->dot_img_offy);
		return OK;
	}


	this->in_loop = 1;
	this->is_moving = 1;
	
	int cx,cy,step;

	cx = 0; cy = 0;
	step = 5;
	
	switch(lparam)
	{
		case KEY_UP: cy = -step; break;
		case KEY_DOWN: cy = step;break;
		case KEY_LEFT: cx = -step;break;
		case KEY_RIGHT: cx = step;break;
	}

	while(this->is_moving)
	{
		this->MoveTo(this->dot_img_offx+cx,this->dot_img_offy+cy);
		MsgLoop();
	}
	
	this->in_loop = 0;

    return OK;
}
int CWndDocReader::OnUnknown(u32 message,int wparam, int lparam)
{	
	if(wparam == this->win_id_filemgr && wparam != 0)
	{
		CMem mem;

		LOCAL_MEM(mem);

		char *fn = (char*)lparam;
		ASSERT(fn);
		
		CDirMgr::GetFileName(fn,&mem,FN_EXT);

		if(mem.StrICmp("dot") != 0)
		{
			CWndMsgBox::Create(this->id,"����","ֻ�ܴ�dot�ļ�.",MB_OK);
			return ERROR;
		}

		this->OpenFile(fn);
	}

	return OK;
}
int CWndDocReader::OnPaint(int wparam, int lparam)
{
	CRect rc;
	CDc *pdc = this->BeginPaint(lparam);
	int ins_pos;
	
	if(this->IsOpened())
	{
		this->GetMapRect(&rc);
		pdc->SetBrushColor(COLOR_WHITE);
		pdc->FillRect(&rc);
		
		pdc->SetPenColor(COLOR_GREEN);
		
		ASSERT(this->dot_img_width > 0);
		
		ins_pos = this->ins_line_pos * rc.GetWidth() / this->dot_img_width;
		if(ins_pos > 0)
			pdc->VLine(rc.left +ins_pos ,rc.top,rc.GetHeight());
		
		pdc->SetPenColor(COLOR_BLUE);
		pdc->DrawRect(&rc);

		this->GetDragRect(&rc);
		pdc->SetPenColor(COLOR_RED);
		pdc->DrawRect(&rc);
	}

	this->EndPaint();

	return OK;
}
int CWndDocReader::Decompress(int x, int y)
{
	ASSERT(this->vram && this->mem_dot_file);
	
	int i,j,tt,size;
	
	char *p = this->mem_dot_file->p + 8;
	
	size = this->dot_img_height * this->dot_img_width;
	if(size <= 0)
		return ERROR;
	
	for(i = 0; i <  UP_SCREEN_HEIGHT; i++)
	{
		for(j = 0; j < UP_SCREEN_WIDTH; j++)
		{
			tt = (i+y)*this->dot_img_width + (j+x);
			
			if(tt < size && (p[ tt >> 3] & ( 1 << (tt & 7) ) ))
				vram[(i<<8) + j] = PA_RGB(0,0,0);
			else
				vram[(i<<8) + j] = PA_RGB(31,31,31);
		}
	}
	
	return OK;
}

int CWndDocReader::GetMapRect(CRect *rc)
{
	ASSERT(rc);

	if(this->dot_img_height <= 0 || this->dot_img_width <= 0)
	{
		rc->Empty();
		return ERROR;
	}
	
	int w,h;
	int maxw = MAP_RECT_WIDTH;
	
	rc->left = 3;
	rc->top = 17;
	
	if(this->dot_img_width < this->dot_img_height)
	{
		h = maxw;
		w = maxw * this->dot_img_width / this->dot_img_height;
	}
	else
	{
		w = maxw;
		h = maxw * this->dot_img_height / this->dot_img_width;
	}
	
	rc->right = rc->left + w - 1;
	rc->bottom = rc->top + h -1;
	
	return OK;
}

int CWndDocReader::GetDragRect(CRect *rc)
{
	ASSERT(rc);
	CRect rt;
	int x,y,w,h;
	
	this->GetMapRect(&rt);
	
	if(this->dot_img_width > UP_SCREEN_WIDTH)
		w = rt.GetWidth() * UP_SCREEN_WIDTH / this->dot_img_width;
	else
		w = rt.GetWidth();
	
	if(this->dot_img_height > UP_SCREEN_HEIGHT)
		h = rt.GetHeight() * UP_SCREEN_HEIGHT / this->dot_img_height;
	else
		h = rt.GetHeight();
	
	
	x = rt.GetWidth() * this->dot_img_offx / this->dot_img_width;
	y = rt.GetHeight() * this->dot_img_offy / this->dot_img_height; 
	
	x += rt.left;
	y += rt.top;
	
	rc->Set(x,y,x+w-1,y+h-1);
	
	return OK;
}

int CWndDocReader::IsDocOpened()
{
	return this->index_file != NULL;
}

int CWndDocReader::OpenFile(char *fn)
{
	NEW(this->file,CFile);
	this->file->Init();	
	
	if( this->file->OpenFile(fn,"rb")  == ERROR)
	{
		LOG("open file error\n");
		return ERROR;
	}

	NEW(this->index_file,CIndexFile);
	this->index_file->Init();
	this->index_file->LoadIndexFile(this->file);

	this->GotoPage(0);

	return OK;
}

int CWndDocReader::CloseFile()
{
	DEL(this->mem_dot_file);
	DEL(this->index_file);
	DEL(this->file);

	return OK;
}

int CWndDocReader::GotoPage(int page)
{
	if(!this->IsDocOpened())
		return ERROR;

	if(page < 0)
		page = 0;
	if(page >= this->index_file->GetTotalBlocks())
		page = this->index_file->GetTotalBlocks() - 1;
	
	this->cur_page = page;
	
	char buf[100];

	sprintf(buf,"%d",page + 1);
	this->leb_page->SetText(buf);

	this->mem_pages->SetSize(0);
	this->mem_pages->Printf("%d/%d",page+1,this->index_file->GetTotalBlocks());
	this->mem_pages->Putc(0);
	
	this->st_1->SetText(this->mem_pages->p);

	int size = this->index_file->GetBlockSize(page);
	ASSERT(size > 0 && size < 1024 * 1024);

	DEL(this->mem_dot_file);

	NEW(this->mem_dot_file,CMem);
	this->mem_dot_file->Init();
	this->mem_dot_file->Malloc(size);
	
	//this->index_file->GetBlock(page,this->mem_dot_file);
	
	int s = this->index_file->GetBlockOff(page);
	int e = this->index_file->GetBlockOff(page + 1);

	this->index_file->i_file->Seek(s);
	this->index_file->i_file->Read(this->mem_dot_file->p,e - s);
	this->mem_dot_file->SetSize(size);

	this->mem_dot_file->Seek(0);
	this->mem_dot_file->Read(&this->dot_img_width,4);
	this->mem_dot_file->Read(&this->dot_img_height,4);

	this->dot_img_offx = 0;
	this->dot_img_offy = 0;
	this->Decompress(0,0);

	this->InvalidateRect(NULL,1);

	return OK;
}

int CWndDocReader::MoveTo(int dot_x, int dot_y)
{
	CRect rc;

	this->GetMapRect(&rc);

	if(dot_x < 0) dot_x = 0;
	if(dot_y < 0) dot_y = 0;

	if(dot_x > this->dot_img_width - UP_SCREEN_WIDTH)
		dot_x = this->dot_img_width - UP_SCREEN_WIDTH;
	if(dot_y > this->dot_img_height- UP_SCREEN_HEIGHT)
		dot_y = this->dot_img_height - UP_SCREEN_HEIGHT;
		
	this->dot_img_offx = dot_x;
	this->dot_img_offy = dot_y;
		
	this->InvalidateRect(&rc,0);
	this->Decompress(this->dot_img_offx,this->dot_img_offy);
	
	return OK;
}

int CWndDocReader::OnClose(int wparam, int lparam)
{
	if(this->in_loop)
		return ERROR;

	return CWindow::OnClose(wparam,lparam);
}

int CWndDocReader::IsOpened()
{
	return this->mem_dot_file != NULL;
}

int CWndDocReader::SetInsLinePos(int x)
{
	CRect r;

	if(x < 0) 
		x = 0;

	if(x > this->dot_img_width)
		x = this->dot_img_width - 1;

	this->ins_line_pos = x;
	
	this->GetMapRect(&r);
	this->InvalidateRect(&r,0);

	return OK;
}
