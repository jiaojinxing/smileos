#ifndef __WNDDOCREADER_H
#define __WNDDOCREADER_H

#include "moongui.h"
#include "indexfile.h"

class CWndDocReader:public CWindow{
public:
	CButton *btn_up;
	CButton *btn_down;
	CLineEditor *leb_page;
	CButton *btn_go;
	CButton *btn_open;
	CStatic *st_1;

	u16 *vram;
	CFile *file;
	CIndexFile *index_file;
	CMem *mem_dot_file;
	CMem *mem_pages;
	int dot_img_width,dot_img_height;
	int dot_img_offx,dot_img_offy;
	int ins_line_pos;
	int drag_mode,drag_offx,drag_offy;
	int win_id_filemgr;
	int cur_page;
	int in_loop,is_moving;
public:
	int SetInsLinePos(int x);
	int IsOpened();
	int OnClose(int wparam, int lparam);
	int OnKeyUp(int wparam, int lparam);
	int MoveTo(int dot_x, int dot_y);
	int GotoPage(int page);
	int CloseFile();
	int OpenFile(char *fn);
	int IsDocOpened();
	int GetDragRect(CRect *rc);
	int GetMapRect(CRect *rc);
	int Decompress(int x,int y);
    CWndDocReader();
    virtual ~CWndDocReader();
    int Init();
    int Destroy();
    int InitBasic();
    int OnCreate(int wparam, int lparam);
    int OnCommand(int wparam, int lparam);
    int OnLButtonDown(int wparam, int lparam);
    int OnLButtonUp(int wparam, int lparam);
    int OnMouseMove(int wparam, int lparam);
    int OnKeyDown(int wparam, int lparam);
    int OnUnknown(u32 message,int wparam, int lparam);
	int OnPaint(int wparam,int lparam);
};

#endif